package com.example.examplemod;

import com.simibubi.create.content.processing.recipe.ProcessingRecipe;
import com.simibubi.create.content.processing.recipe.ProcessingRecipeBuilder;
import com.simibubi.create.foundation.recipe.IRecipeTypeInfo;
import net.minecraft.world.level.Level;
import net.minecraftforge.items.wrapper.RecipeWrapper;

import javax.annotation.ParametersAreNonnullByDefault;

@ParametersAreNonnullByDefault
public class HoneyingRecipe extends ProcessingRecipe<RecipeWrapper> {
    public HoneyingRecipe(ProcessingRecipeBuilder.ProcessingRecipeParams params) {
        super(RecipeTypes.HONEYING, params);
    }

    @Override
    public boolean matches(RecipeWrapper recipeWrapper, Level level) {
        if (recipeWrapper.isEmpty()) {
            return false;
        }

        return ingredients.get(0).test(recipeWrapper.getItem(0));
    }

    @Override
    protected int getMaxInputCount() {
        return 1;
    }

    @Override
    protected int getMaxOutputCount() {
        return 12;
    }
}
